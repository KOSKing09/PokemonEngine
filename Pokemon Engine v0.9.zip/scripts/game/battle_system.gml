// [Battle] PokemonBattleSystem — Build v0.1.33
// Updated 2025-10-07
// - New: Command handling (A/B). Root menu routes to Fight/Bag/Pokémon/Run
// - New: Fight submenu shows 2×2 move grid with names & PP (uses scr_move_name_by_id if present)
// - New: RUN closes wild battle immediately (stub); shows "Got away safely!" if dialog system exists
// - New: Selecting a move opens a stub dialog "TODO: used {move}" and returns to root afterward
// - Keep: GUI-only, PID-aware, letterbox fit; dialog font guard; DS cleanup on close
// -----------------------------------------------------------------------------
// CALLS you’ll use in objects:
//   battle_open(pid, wild_level);      // e.g., battle_open(0, irandom_range(5,18));
//   battle_update(pid);                // Step Event
//   battle_draw_gui(pid);              // Draw GUI Event
//   battle_close(pid);                 // when done
// -----------------------------------------------------------------------------

// ===== Slot helpers (per-player battle state) =====
function __battle_ensure_slot(_pid){
    if (!variable_global_exists("sys_battles") || !is_array(global.sys_battles)) global.sys_battles = [];
    if (array_length(global.sys_battles) <= _pid) array_resize(global.sys_battles, _pid + 1);
    var _B = global.sys_battles[_pid];
    if (!is_struct(_B)) { _B = { sys_open:false }; global.sys_battles[_pid] = _B; }
    return _B;
}
function battle_is_open(_pid){
    var _B = __battle_ensure_slot(_pid);
    return (_B.sys_open == true);
}

// ===== Open / Close =====
function battle_open(_a0, _a1){
    var _pid = 0, _wildLevel = 5;
    if (argument_count >= 2){ _pid = max(0, real(_a0)); _wildLevel = max(1, real(_a1)); }
    else if (argument_count == 1){ _pid = 0; _wildLevel = max(1, real(_a0)); }
    var _caller = noone;
    if (!is_undefined(player_by_pid)) {
        _caller = player_by_pid(_pid);
        if (_caller == noone) _caller = noone;
    }

    var _B = __battle_ensure_slot(_pid);
    if (_B.sys_open) return;

    _B.sys_open = true;
    _B.phase    = "transition_in";
    _B.turn     = 0;
    _B.result   = "ongoing";
    _B.sys_rng  = random_get_seed();

    _B.sys_ui   = { menu:"root", selX:0, selY:0, msg_list:ds_list_create() };
    _B.sys_anim = { active:[
        {anim_id:"idle",timer:0,duration:999999,offX:0,offY:0,scale:1},
        {anim_id:"idle",timer:0,duration:999999,offX:0,offY:0,scale:1}
    ]};
    _B.phase_start_ms = current_time;
    _B.phase_durs = { transition: 300, enemy: 400, call: 700, player: 400, switch_in: 600 };
    _B._intro_completed = false;
    _B.phase_holds = { call: 3000 };
    _B._pending_close = false; // set true to close when dialog ends

    _B.theme = {
        col_bg:       make_color_rgb(184,224,200),
        col_outline:  make_color_rgb(72,88,80),
        col_panel:    make_color_rgb(208,232,224),
        col_hp_green: make_color_rgb(120,216,88),
        col_hp_yell:  make_color_rgb(248,208,56),
        col_hp_red:   make_color_rgb(232,72,56),
        col_text:     c_white
    };

    // Player actor from that player's party
    var _P = party_ensure(_pid);
    var _mons = _P.mons;
    var _first = 0;
    for (var _i=0; _i<array_length(_mons); ++_i){
        var _m = _mons[_i];
        if (!is_undefined(_m) && is_struct(_m) && variable_struct_exists(_m,"hp") && _m.hp > 0){ _first = _i; break; }
    }
    var _pm = _mons[_first];

    _B.actor = [];
    _B.actor[0] = __battle_actor_from_party_mon(_pm);

    // Wild actor (1..901 only)
    var _sp = irandom_range(1, 901);
    _B.actor[1] = __battle_actor_from_species_level(_sp, _wildLevel);

    _B.caller = _caller;
    if (_B.caller != noone && instance_exists(_B.caller) && variable_instance_exists(_B.caller, "battleAnim") && sprite_exists(_B.caller.battleAnim)){
        _B.caller_battleAnim = _B.caller.battleAnim;
    } else if (variable_global_exists("battleAnim") && sprite_exists(battleAnim)){
        _B.caller_battleAnim = battleAnim;
    } else {
        _B.caller_battleAnim = undefined;
    }

    if (!is_undefined(dialog2p_open_text)){
        var dlg_txt = "A wild " + string(_B.actor[1].name) + " has appeared!\n\nGo. " + string(_B.actor[0].name) + "!";
    dialog2p_open_text(_pid, dlg_txt);
    _B._dlg_active = true;
    _B._dlg_page_last = -1;
    } else {
        _B._dlg_active = false;
        _B._dlg_page_last = -1;
    }

    __battle_apply_party_moves(_B.actor[0]);   // <- copy moves/PP from the party mon if present
    __battle_ensure_moves_from_levelup(_B.actor[1]);

    global.sys_battles[_pid] = _B;
}
function battle_close(_pid){
    var _B = __battle_ensure_slot(_pid);
    if (is_struct(_B.sys_ui) && variable_struct_exists(_B.sys_ui, "msg_list")){
        if (ds_exists(_B.sys_ui.msg_list, ds_type_list)){
            ds_list_destroy(_B.sys_ui.msg_list);
        }
    }
    _B.sys_open = false;
}

// ===== Update / Draw =====
function battle_update(_pid){
    if (!battle_is_open(_pid)) return;
    var _B = __battle_ensure_slot(_pid);
    // Dialog override: if the dialog system is present, update it and drive the intro
    var dlg_open = (is_undefined(dialog2p_is_open) ? false : dialog2p_is_open(_pid));
    if (dlg_open){
        if (!is_undefined(dialog2p_update)) dialog2p_update(_pid);
        var d = global.DIALOG2P[_pid];
        var page = (is_struct(d) ? d.page_idx : 0);
        // detect page changes and drive phases accordingly
        if (!variable_struct_exists(_B, "_dlg_page_last")) _B._dlg_page_last = -1;
        if (page != _B._dlg_page_last){
            var now = current_time;
            // Only allow dialog pages to drive the intro phases before the intro has completed
            if (!variable_struct_exists(_B, "_intro_completed") || !_B._intro_completed){
                if (page == 0){
                    if (string(_B.phase) == "transition_in"){
                        _B.phase = "intro_enemy";
                        _B.phase_start_ms = now;
                    }
                } else if (page == 1){
                    _B.phase = "intro_call";
                    _B.phase_start_ms = now;
                }
            }
            _B._dlg_page_last = page;
        }
        // Update phase progress so sliding/animations advance while dialog is visible
        var now2 = current_time;
        if (string(_B.phase) == "intro_enemy"){
            var dur_e = _B.phase_durs.enemy;
            var elapsed_e = now2 - (variable_struct_exists(_B,"phase_start_ms") ? _B.phase_start_ms : now2);
            _B.phase_progress = max(0, min(1, elapsed_e / max(1, dur_e)));
        } else if (string(_B.phase) == "intro_call"){
            var dur_c = _B.phase_durs.call;
            var elapsed_c = now2 - (variable_struct_exists(_B,"phase_start_ms") ? _B.phase_start_ms : now2);
            _B.phase_progress = max(0, min(1, elapsed_c / max(1, dur_c)));
        } else if (string(_B.phase) == "intro_player"){
            var dur_p = _B.phase_durs.player;
            var elapsed_p = now2 - (variable_struct_exists(_B,"phase_start_ms") ? _B.phase_start_ms : now2);
            _B.phase_progress = max(0, min(1, elapsed_p / max(1, dur_p)));
        }
        _B._dlg_active = true;
        return;
    }

    // If dialog just closed, advance into the player intro (scale-up) or run pending close
    if (variable_struct_exists(_B, "_dlg_active") && _B._dlg_active){
        var now3 = current_time;
        _B._dlg_active = false;
        _B._dlg_page_last = -1;
        if (_B.phase == "intro_call"){
            _B.phase = "intro_player";
            _B.phase_start_ms = now3;
        } else if (_B._pending_close){
            // after a dialog that told the player we escaped, close
            _B._pending_close = false;
            battle_close(_pid);
            return;
        }
        // After any stub dialog (e.g., move used), snap menu back to root
        if (string(_B.phase) == "command"){
            _B.sys_ui.menu = "root";
            _B.sys_ui.selX = 0;
            _B.sys_ui.selY = 0;
        }
    }

    // Handle intro sequencing phases
    if (string(_B.phase) == "transition_in" || string(_B.phase) == "intro_enemy" || string(_B.phase) == "intro_call" || string(_B.phase) == "intro_player" || string(_B.phase) == "switch_in"){
        var now4 = current_time;
        var stage = string(_B.phase);
        var start = (variable_struct_exists(_B,"phase_start_ms") ? _B.phase_start_ms : now4);
        if (stage == "transition_in"){
            var dur = _B.phase_durs.transition;
            var elapsed = now4 - start;
            _B.phase_progress = max(0, min(1, elapsed / max(1,dur)));
            if (elapsed >= dur){ _B.phase = "intro_enemy"; _B.phase_start_ms = now4; }
            else return;
        }
        if (stage == "intro_enemy"){
            var dur2 = _B.phase_durs.enemy;
            var elapsed2 = now4 - start;
            _B.phase_progress = max(0, min(1, elapsed2 / max(1,dur2)));
            if (elapsed2 >= dur2){
                _B.phase = "intro_call";
                _B.phase_start_ms = now4;
            }
            else return;
        } else if (stage == "intro_call"){
            var dur3 = _B.phase_durs.call;
            var hold_ms = 0;
            if (variable_struct_exists(_B, "phase_holds") && variable_struct_exists(_B.phase_holds, "call")) hold_ms = max(0, real(_B.phase_holds.call));
            var elapsed3 = now4 - start;
            _B.phase_progress = max(0, min(1, elapsed3 / max(1,dur3)));
            if (elapsed3 >= dur3 + hold_ms){ _B.phase = "intro_player"; _B.phase_start_ms = now4; }
            else return;
        } else if (stage == "intro_player"){
            var dur4 = _B.phase_durs.player;
            var elapsed4 = now4 - start;
            _B.phase_progress = max(0, min(1, elapsed4 / max(1,dur4)));
            if (elapsed4 >= dur4){
                _B.phase = "command";
                _B._intro_completed = true;
            }
            else return;
        }
        else if (stage == "switch_in"){
            var dur5 = (_B.phase_durs.switch_in || 400);
            var elapsed5 = now4 - start;
            _B.phase_progress = max(0, min(1, elapsed5 / max(1,dur5)));
            if (elapsed5 >= dur5){
                _B.phase = "command";
            } else return;
        }
    }
    __battle_process_input(_pid);
}

function battle_draw_gui(_pid){
    var _rect = __battle_view_rect_for_pid(_pid); // [rx,ry,rw,rh] letterboxed inside GUI
    if (is_array(_rect) && array_length(_rect) >= 4) {
        battle_draw_gui_rect(_pid, _rect[0], _rect[1], _rect[2], _rect[3]);
    }
}

// Draw the battle UI inside a given GUI rect (matches party_draw_gui_rect style)
function battle_draw_gui_rect(_pid, _rx, _ry, _rw, _rh){
    if (!battle_is_open(_pid)) return;
    var _B = __battle_ensure_slot(_pid);

    // Compute integer UI scale (like party system) so caller can assign rects for split-screen
    var _S  = max(1, min(floor(_rw / 240), floor(_rh / 160)));
    var _OX = _rx + (_rw - 240 * _S) div 2;
    var _OY = _ry + (_rh - 160 * _S) div 2;

    // Begin UI transform
    __bui_begin(_pid, _OX, _OY, 240*_S, 160*_S);

    // Set default font
    if (variable_global_exists("FNT_POKEMON")) draw_set_font(global.FNT_POKEMON); else draw_set_font(-1);
    draw_set_color(c_white);

    // background
    draw_set_color(_B.theme.col_bg);
    draw_rectangle(__bxu(_pid,0), __byu(_pid,0), __bxu(_pid,240), __byu(_pid,160), false);

    // draw battler sprites
    __battle_draw_battlers(_pid, _B);

    // HUD boxes
    __battle_enemy_box_rect(_pid, 16,16,112,40, _B.actor[1]);
    __battle_player_box_rect(_pid,112,104,128,48, _B.actor[0]);
    __battle_cmd_box_rect(_pid,   8,136,224,24,   _B.sys_ui.selX, _B.sys_ui.selY); // 136+24=160

    // transition fade
    if (string(_B.phase) == "transition_in"){
        var p = (variable_struct_exists(_B,"phase_progress") ? _B.phase_progress : 0);
        var alpha = 1 - max(0, min(1, p));
        draw_set_color(c_black);
        draw_set_alpha(alpha);
        draw_rectangle(__bxu(_pid,0), __byu(_pid,0), __bxu(_pid,240), __byu(_pid,160), false);
        draw_set_alpha(1);
    }

    __bui_end(_pid);
}

// ===== Input (PID-aware; falls back to keyboard) =====
function __battle_pressed(_pid, _name){
    // 1) Your control system — try common aliases
    if (!is_undefined(controls_pressed)){
        var aliases, i;

        if (_name=="Left"){
            aliases = ["MoveLeft","Left","UILeft","DPadLeft"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }
        if (_name=="Right"){
            aliases = ["MoveRight","Right","UIRight","DPadRight"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }
        if (_name=="Up"){
            aliases = ["MoveUp","Up","UIUp","DPadUp"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }
        if (_name=="Down"){
            aliases = ["MoveDown","Down","UIDown","DPadDown"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }

        // A / B accept lots of labels
        if (_name=="A"){
            aliases = ["A","Confirm","Accept","Interact","Select","ButtonA"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }
        if (_name=="B"){
            aliases = ["B","Cancel","Back","Pause","ButtonB"];
            for (i=0; i<array_length(aliases); ++i) if (controls_pressed(_pid, aliases[i])) return true;
        }
    }

    // 2) Keyboard fallbacks (no gamepad / no built-in instance vars)
    if (_name=="Left")  return keyboard_check_pressed(vk_left);
    if (_name=="Right") return keyboard_check_pressed(vk_right);
    if (_name=="Up")    return keyboard_check_pressed(vk_up);
    if (_name=="Down")  return keyboard_check_pressed(vk_down);

    // A: Enter / Space / Z
    if (_name=="A") return (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")));
    // B: Esc / Backspace / X
    if (_name=="B") return (keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) || keyboard_check_pressed(ord("X")));

    return false;
}
function __battle_process_input(_pid){
    var _B = __battle_ensure_slot(_pid);
    // only allow input after command phase
    if (string(_B.phase) != "command") return;

    var _l = __battle_pressed(_pid,"Left");
    var _r = __battle_pressed(_pid,"Right");
    var _u = __battle_pressed(_pid,"Up");
    var _d = __battle_pressed(_pid,"Down");
    var _a = __battle_pressed(_pid,"A");
    var _b = __battle_pressed(_pid,"B");

    // grid navigation (2×2)
    if (_l) _B.sys_ui.selX = max(0, _B.sys_ui.selX - 1);
    if (_r) _B.sys_ui.selX = min(1, _B.sys_ui.selX + 1);
    if (_u) _B.sys_ui.selY = max(0, _B.sys_ui.selY - 1);
    if (_d) _B.sys_ui.selY = min(1, _B.sys_ui.selY + 1);

    var menu = string(_B.sys_ui.menu);
    var idx = _B.sys_ui.selX + _B.sys_ui.selY * 2;

    if (_b){
        if (menu == "fight"){
            _B.sys_ui.menu = "root";
            _B.sys_ui.selX = 0; _B.sys_ui.selY = 0;
        } else {
            // later: allow backing from submenus; root has no effect
        }
    }

    if (_a){
        if (menu == "root"){
            // 0:FIGHT,1:BAG,2:POKEMON,3:RUN
            if (idx == 0){
                _B.sys_ui.menu = "fight";
                _B.sys_ui.selX = 0; _B.sys_ui.selY = 0;
            }
            else if (idx == 1){
                __battle_stub_dialog(_pid, "Your bag isn't hooked up yet.\n(TODO: open bag UI)");
            }
            else if (idx == 2){
                __battle_stub_dialog(_pid, "You checked your party.\n(TODO: switch Pokémon)");
            }
            else if (idx == 3){
                __battle_try_escape(_pid);
            }
        }
        else if (menu == "fight"){
            var move_idx = idx;
            var A = _B.actor[0];
            var mv = A.moves[move_idx];
            var pp = A.pps[move_idx];
            if (!is_real(mv) || mv < 0){
                __battle_stub_dialog(_pid, "No move registered there.\n(Try another slot.)");
            } else if (pp <= 0){
                __battle_stub_dialog(_pid, "There's no PP left for that move!\n(TODO: implement Struggle.)");
            } else {
                var name = __battle_move_name(mv);
                A.pps[move_idx] = max(0, pp - 1);
                __battle_stub_dialog(_pid, string(A.name) + " used " + name + "!\n(TODO: resolve damage.)");
            }
        }
    }
}

// ===== Helpers: menus, run, moves =====
function __battle_menu_index(_selX,_selY){ return _selX + _selY*2; }
function __battle_move_name(_id){
    if (is_real(_id) && _id >= 0){
        if (!is_undefined(scr_move_name_by_id)) return scr_move_name_by_id(_id);
        return "MOVE " + string(_id);
    }
    return "--";
}
function __battle_try_escape(_pid){
    var _B = __battle_ensure_slot(_pid);
    _B.result = "escaped";
    if (!is_undefined(dialog2p_open_text)){
        dialog2p_open_text(_pid, "Got away safely!\n");
        _B._pending_close = true;
    } else {
        battle_close(_pid);
    }
}
function __battle_stub_dialog(_pid, _text){
    if (!is_undefined(dialog2p_open_text)){
        dialog2p_open_text(_pid, _text);
    var _B = __battle_ensure_slot(_pid);
    _B._dlg_active = true;
    _B._dlg_page_last = -1;
    }
}
// Start a switch-in animation/phase for the active player's party (trainer animation will play during this phase)
function __battle_play_switch_in(_pid){
    var _B = __battle_ensure_slot(_pid);
    if (!is_struct(_B) || !_B.sys_open) return;
    _B.phase = "switch_in";
    _B.phase_start_ms = current_time;
    _B.phase_progress = 0;
}

// High-level API: switch the player's active Pokémon to the party index with visuals
// opts: { auto_apply:true/false, callback:function }
function battle_switch_to(_pid, _party_idx, _opts){
    var _B = __battle_ensure_slot(_pid);
    if (!is_struct(_B) || !_B.sys_open) return false;
    if (string(_B.phase) != "command") return false; // don't start during other flows

    if (is_undefined(_opts)) _opts = {};
    _B._switch_target_idx = _party_idx;
    _B._switch_opts = _opts;
    // start the visual phase (trainer anim will play because phase == switch_in)
    _B.phase = "switch_in";
    _B.phase_start_ms = current_time;
    _B.phase_progress = 0;
    return true;
}
function __battle_text_fit_ellipsis(_pid, _str, _max_px){
    var s = string(_str);
    if (string_width(s) <= _max_px) return s;

    var ell = "…";
    var n = string_length(s);
    // Trim from the end until it fits (add ellipsis)
    while (n > 1){
        n -= 1;
        var cand = string_copy(s, 1, n) + ell;
        if (string_width(cand) <= _max_px) return cand;
    }
    return ell;
}

// ===== Actor creation =====
function __battle_actor_from_party_mon(_M){
    var _sid = -1;
    if (variable_struct_exists(_M,"id") && is_real(_M.id)) _sid = _M.id;
    else if (variable_struct_exists(_M,"species_id") && is_real(_M.species_id)) _sid = _M.species_id;

    var _nm = "???";
    if (variable_struct_exists(_M,"name") && is_string(_M.name) && string_length(_M.name) > 0) _nm = string(_M.name);
    else if (_sid > 0) _nm = scr_poke_name_by_id(_sid);

    var _hpMax = 20;
    if (variable_struct_exists(_M,"hp_max"))      _hpMax = _M.hp_max;
    else if (variable_struct_exists(_M,"maxhp"))  _hpMax = _M.maxhp;

    var _hpNow = variable_struct_exists(_M,"hp") ? _M.hp : _hpMax;

    var _lvl   = 5;
    if (variable_struct_exists(_M,"level")) _lvl = _M.level;
    else if (variable_struct_exists(_M,"lvl")) _lvl = _M.lvl;

    var _actor = {
        species : _sid,
        level   : _lvl,
        name    : _nm,
        hp_now  : _hpNow,
        hp_max  : _hpMax,
        moves   : [-1,-1,-1,-1],
        pps     : [0,0,0,0]
    };
    if (is_struct(_M)) {
        _actor.mon = _M;
        if ((!variable_struct_exists(_actor.mon, "species_id") || !is_real(_actor.mon.species_id))) {
            if (variable_struct_exists(_actor.mon, "id") && is_real(_actor.mon.id)) {
                _actor.mon.species_id = _actor.mon.id;
            } else if (variable_struct_exists(_actor.mon, "species") && is_real(_actor.mon.species)) {
                _actor.mon.species_id = _actor.mon.species;
            }
        }
    } else {
        _actor.mon = { species_id:_sid, shiny:false };
    }
    return _actor;
}
function __battle_actor_from_species_level(_sp,_lvl){
    var _nm = scr_poke_name_by_id(_sp);
    var _actor = {
        species:_sp,
        level:_lvl,
        name:_nm,
        hp_now:30,
        hp_max:30,
        moves:[-1,-1,-1,-1],
        pps:[0,0,0,0]
    };
    _actor.mon = { species_id:_sp, shiny:false };
    return _actor;
}

// ===== Move population =====
function __battle_ensure_moves_from_levelup(_A){
    // clear
    for (var i=0; i<4; ++i){ _A.moves[i] = -1; _A.pps[i] = 0; }

    var cand = [];

    if (!is_undefined(scr_poke_moveset_by_id)){
        var pool = scr_poke_moveset_by_id(_A.species);

        // Accept arrays OR ds_lists; entries may be [move, level] or just move
        if (is_array(pool)){
            for (var j = 0; j < array_length(pool); ++j){
                var entry = pool[j];
                var mv = -1, reqLv = -1;
                if (is_array(entry)){
                    if (array_length(entry) >= 1 && is_real(entry[0])) mv = entry[0];
                    if (array_length(entry) >= 2 && is_real(entry[1])) reqLv = entry[1];
                } else if (is_real(entry)){
                    mv = entry;
                }
                if (is_real(mv) && mv >= 0 && (reqLv < 0 || _A.level >= reqLv)){
                    cand[array_length(cand)] = mv; // push
                }
            }
        } else if (ds_exists(pool, ds_type_list)){
            var n = ds_list_size(pool);
            for (var k = 0; k < n; ++k){
                var entry2 = ds_list_find_value(pool, k);
                var mv2 = -1, reqLv2 = -1;
                if (is_array(entry2)){
                    if (array_length(entry2) >= 1 && is_real(entry2[0])) mv2 = entry2[0];
                    if (array_length(entry2) >= 2 && is_real(entry2[1])) reqLv2 = entry2[1];
                } else if (is_real(entry2)){
                    mv2 = entry2;
                }
                if (is_real(mv2) && mv2 >= 0 && (reqLv2 < 0 || _A.level >= reqLv2)){
                    cand[array_length(cand)] = mv2; // push
                }
            }
        }
    }

    // take the most recent 4 (from the end)
    var total = array_length(cand);
    if (total > 0){
        var take = min(4, total);
        for (var m = 0; m < take; ++m){
            var mvPick = cand[total - 1 - m];
            _A.moves[m] = mvPick;
            _A.pps[m]   = 10; // placeholder PP
        }
    } else {
        // fallback so FIGHT isn't empty
        _A.moves[0] = 1;
        _A.pps[0]   = 10;
    }
}
function __battle_apply_party_moves(_A){
    // clear
    for (var i=0; i<4; ++i){ _A.moves[i] = -1; _A.pps[i] = 0; }

    var m = (is_struct(_A) && variable_struct_exists(_A, "mon")) ? _A.mon : undefined;
    if (!is_struct(m)) { __battle_ensure_moves_from_levelup(_A); return; }

    var got = 0;

    // ---- CASE 1: mon.moves (array)
    if (variable_struct_exists(m, "moves") && is_array(m.moves)){
        var mvArr = m.moves;
        var ppArr = (variable_struct_exists(m, "pps") && is_array(m.pps)) ? m.pps : undefined;

        var cnt = min(4, array_length(mvArr));
        for (var i1 = 0; i1 < cnt; ++i1){
            var e = mvArr[i1];
            var mvCode = -1;
            var havePP = false;
            var ppVal = 0;

            if (is_real(e)){
                mvCode = e;
                if (is_array(ppArr) && i1 < array_length(ppArr) && is_real(ppArr[i1])){
                    ppVal = max(0, real(ppArr[i1])); havePP = true;
                }
            } else if (is_array(e)){
                // Treat [move, pp] if provided
                if (array_length(e) >= 1 && is_real(e[0])) mvCode = e[0];
                if (array_length(e) >= 2 && is_real(e[1])) { ppVal = max(0, real(e[1])); havePP = true; }
            } else if (is_struct(e)){
                // Accept several field names without using a local named 'id'
                if (variable_struct_exists(e, "move")     && is_real(e.move))     mvCode = e.move;
                else if (variable_struct_exists(e, "move_id") && is_real(e.move_id)) mvCode = e.move_id;
                else if (variable_struct_exists(e, "id")  && is_real(e.id))       mvCode = e.id; // struct field ok

                if (variable_struct_exists(e, "pp")       && is_real(e.pp))       { ppVal = max(0, real(e.pp)); havePP = true; }
                else if (variable_struct_exists(e, "pp_cur") && is_real(e.pp_cur)){ ppVal = max(0, real(e.pp_cur)); havePP = true; }
                else if (variable_struct_exists(e, "pp_current") && is_real(e.pp_current)){ ppVal = max(0, real(e.pp_current)); havePP = true; }
            }

            if (is_real(mvCode) && mvCode >= 0){
                _A.moves[i1] = mvCode;
                _A.pps[i1]   = havePP ? ppVal : 10; // default PP if not supplied
                got += 1;
            }
        }
    }

    // ---- CASE 2: mon.move1..move4 (and pp1..pp4)
    if (got == 0){
        var moved = false;
        for (var i2 = 0; i2 < 4; ++i2){
            var idx = i2 + 1;
            var mvField = "move" + string(idx);
            if (variable_struct_exists(m, mvField) && is_real(variable_get(m, mvField))){
                var mvVal = real(variable_get(m, mvField));
                if (mvVal >= 0){
                    _A.moves[i2] = mvVal;
                    moved = true;

                    var ppField = "pp" + string(idx);
                    if (variable_struct_exists(m, ppField) && is_real(variable_get(m, ppField))){
                        _A.pps[i2] = max(0, real(variable_get(m, ppField)));
                    } else {
                        _A.pps[i2] = 10;
                    }
                }
            }
        }
        if (moved){
            got = 1;
        }
    }

    // ---- CASE 3: parallel arrays with different field names (move_ids / pps)
    if (got == 0){
        var mvAlt = undefined, ppAlt = undefined;
        if (variable_struct_exists(m, "move_ids") && is_array(m.move_ids)) mvAlt = m.move_ids;
        else if (variable_struct_exists(m, "known_moves") && is_array(m.known_moves)) mvAlt = m.known_moves;
        if (variable_struct_exists(m, "pps") && is_array(m.pps)) ppAlt = m.pps;

        if (is_array(mvAlt)){
            var cnt2 = min(4, array_length(mvAlt));
            for (var i3 = 0; i3 < cnt2; ++i3){
                var mvV = mvAlt[i3];
                if (is_real(mvV) && mvV >= 0){
                    _A.moves[i3] = mvV;
                    _A.pps[i3]   = (is_array(ppAlt) && i3 < array_length(ppAlt) && is_real(ppAlt[i3]))
                                   ? max(0, real(ppAlt[i3])) : 10;
                    got += 1;
                }
            }
        }
    }

    // Fallback if nothing usable was found
    if (got == 0){
        __battle_ensure_moves_from_levelup(_A);
    }
}



// ===== Rect pipeline (PID-aware, GUI-only) =====
function __bui_begin(_pid,_rx,_ry,_rw,_rh){
    var _B = __battle_ensure_slot(_pid);
    var base_w = 240, base_h = 160;
    var sx = _rw / base_w;
    var sy = _rh / base_h;
    var s = min(sx, sy);
    var content_w = floor(base_w * s);
    var content_h = floor(base_h * s);
    var origin_x = _rx + floor((_rw - content_w) / 2);
    var origin_y = _ry + floor((_rh - content_h) / 2);
    _B._ui = { rx: origin_x, ry: origin_y, rw: content_w, rh: content_h, base_w: base_w, base_h: base_h, s: s };
}
function __bui_end(_pid){
    var _B = __battle_ensure_slot(_pid);
    _B._ui = undefined;
}
function __bxu(_pid,_xv){
    var _u = __battle_ensure_slot(_pid)._ui;
    if (is_undefined(_u)) return _xv;
    return floor(_u.rx + _xv * _u.s);
}
function __byu(_pid,_yv){
    var _u = __battle_ensure_slot(_pid)._ui;
    if (is_undefined(_u)) return _yv;
    return floor(_u.ry + _yv * _u.s);
}
function __bwu(_pid,_wv){
    var _u = __battle_ensure_slot(_pid)._ui;
    if (is_undefined(_u)) return _wv;
    return floor(_wv * _u.s);
}
function __bhu(_pid,_hv){
    var _u = __battle_ensure_slot(_pid)._ui;
    if (is_undefined(_u)) return _hv;
    return floor(_hv * _u.s);
}


// ===== Panels & HUD (PID-aware) =====
function __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn){
    var _t  = __battle_ensure_slot(_pid).theme;
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn);
    var _bw = __bwu(_pid,_rwIn), _bh = __bhu(_pid,_rhIn);
    draw_set_color(_t.col_outline); draw_rectangle(_bx,_by,_bx+_bw,_by+_bh,false);
    draw_set_color(_t.col_panel);   draw_rectangle(_bx+1,_by+1,_bx+_bw-1,_by+_bh-1,false);
}
function __battle_enemy_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_A){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn);
    draw_set_color(_t.col_text);
    draw_text(_bx+__bwu(_pid,8), _by+__bhu(_pid,6), string(_A.name));
    draw_text(_bx+_bw-__bwu(_pid,29), _by+__bhu(_pid,6), "Lv"+string(_A.level));
    var _pct = max(0, min(1, _A.hp_now / max(1,_A.hp_max)));
    var _barW = _bw-__bwu(_pid,32), _barX=_bx+__bwu(_pid,8), _barY=_by+__bhu(_pid,20), _bh=__bhu(_pid,6);
    draw_set_color(c_black); draw_rectangle(_barX-1,_barY-1,_barX+_barW+1,_barY+_bh+1,false);
    var _hpcol = _t.col_hp_green; if (_pct<0.5) _hpcol=_t.col_hp_yell; if (_pct<0.2) _hpcol=_t.col_hp_red;
    draw_set_color(_hpcol); draw_rectangle(_barX,_barY,_barX+_barW*_pct,_barY+_bh,false);
}
function __battle_player_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_A){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn);
    draw_set_color(_t.col_text);
    draw_text(_bx+__bwu(_pid,8), _by+__bhu(_pid,6), string(_A.name));
    draw_text(_bx+_bw-__bwu(_pid,32), _by+__bhu(_pid,6), "Lv"+string(_A.level));
    var _pct = max(0, min(1, _A.hp_now / max(1,_A.hp_max)));
    var _barW = _bw-__bwu(_pid,32), _barX=_bx+__bwu(_pid,8), _barY=_by+__bhu(_pid,20), _bh=__bhu(_pid,6);
    draw_set_color(c_black); draw_rectangle(_barX-1,_barY-1,_barX+_barW+1,_barY+_bh+1,false);
    var _hpcol = _t.col_hp_green; if (_pct<0.5) _hpcol=_t.col_hp_yell; if (_pct<0.2) _hpcol=_t.col_hp_red;
    draw_set_color(_hpcol); draw_rectangle(_barX,_barY,_barX+_barW*_pct,_barY+_bh,false);
    draw_text(_bx+_bw-__bwu(_pid,64), _by+__bhu(_pid,18), string(_A.hp_now)+"/"+string(_A.hp_max));
}
function __battle_cmd_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_selX,_selY){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn), _bh = __bhu(_pid,_rhIn);

    // If the dialog box is open for this PID, render dialog (clamped)
    if (!is_undefined(dialog2p_is_open) && dialog2p_is_open(_pid)){
        var d = global.DIALOG2P[_pid];
        if (is_struct(d)){
            var i0 = d.page_idx*2, i1 = i0+1;
            var l0 = (i0 < array_length(d.all_lines)) ? d.all_lines[i0] : "";
            var l1 = (i1 < array_length(d.all_lines)) ? d.all_lines[i1] : "";
            var page_str = l0 + "\n" + l1;
            var vis_str = string_copy(page_str, 1, d.char_idx);

            var vis0 = vis_str, vis1 = "";
            var npos = string_pos("\n", vis_str);
            if (npos > 0){
                vis0 = string_copy(vis_str, 1, npos - 1);
                vis1 = string_copy(vis_str, npos + 1, string_length(vis_str));
            }

            // Clamp each visible line to box width
            var maxW = _bw - __bwu(_pid,16);
            vis0 = __battle_text_fit_ellipsis(_pid, vis0, maxW);
            vis1 = __battle_text_fit_ellipsis(_pid, vis1, maxW);

            if (variable_global_exists("FNT_POKEMON")) draw_set_font(global.FNT_POKEMON);
            draw_set_color(_t.col_text);
            var _fh = (!is_undefined(__dlg_font_h) ? __dlg_font_h() : 8);
            draw_text(_bx + __bwu(_pid,8), _by + __bhu(_pid,6), vis0);
            draw_text(_bx + __bwu(_pid,8), _by + __bhu(_pid,6) + __bhu(_pid, _fh + 2), vis1);
        }
        return;
    }

    var _B = __battle_ensure_slot(_pid);

    // FIGHT submenu: 2×2 moves, clamp each cell’s text
    if (string(_B.sys_ui.menu) == "fight"){
        var restoreFont = -1;
        if (variable_global_exists("FNT_POKEMON")) restoreFont = global.FNT_POKEMON;
        if (variable_global_exists("FNT_POKEMON_SMALL")) draw_set_font(global.FNT_POKEMON_SMALL);

        var A = _B.actor[0];
        var cellW = (_bw * 0.5) - __bwu(_pid,16); // left margin 12 + right ~4
        for (var i=0; i<4; ++i){
            var col = i % 2;
            var row = i div 2;
            var tx = _bx + __bwu(_pid,12) + (col * (_bw * 0.5));
            var ty = _by + __bhu(_pid,6)  + (row * (_bh * 0.5));
            var hilite = (_selX == col) && (_selY == row);

            var mv = A.moves[i];
            var pp = A.pps[i];
            var nm = __battle_move_name(mv);
            var label = nm + "  " + (is_real(pp) ? string(pp) : "0") + " PP";
            label = __battle_text_fit_ellipsis(_pid, label, cellW);

            draw_set_color(hilite ? c_yellow : _t.col_text);
            draw_text(tx, ty, label);
        }

        if (restoreFont != -1) draw_set_font(restoreFont);
        return;
    }

    // Root menu (also clamped for safety)
    var labels = ["FIGHT","BAG","POK\u00E9MON","RUN"];
    var restoreFont2 = -1;
    if (variable_global_exists("FNT_POKEMON")) restoreFont2 = global.FNT_POKEMON;
    if (variable_global_exists("FNT_POKEMON_SMALL")) draw_set_font(global.FNT_POKEMON_SMALL);

    var rootCellW = (_bw * 0.5) - __bwu(_pid,16);
    for (var j=0; j<4; ++j){
        var tx2 = _bx + __bwu(_pid,12) + ((j % 2) * (_bw * 0.5));
        var ty2 = _by + __bhu(_pid,6)  + (floor(j / 2) * (_bh * 0.5));
        var hilite2 = (_selX == (j % 2)) && (_selY == floor(j / 2));
        var lbl = __battle_text_fit_ellipsis(_pid, labels[j], rootCellW);
        draw_set_color(hilite2 ? c_yellow : _t.col_text);
        draw_text(tx2, ty2, lbl);
    }
    if (restoreFont2 != -1) draw_set_font(restoreFont2);
}

// ===== GUI Letterbox rect (per PID, GUI-only; cameras ignored) =====
function __battle_view_rect_for_pid(_pid){
    var _gw = display_get_gui_width();
    var _gh = display_get_gui_height();

    var _logic_w = 240;
    var _logic_h = 160;
    var _aspect  = _logic_w / _logic_h; // 1.5
    var _guiAsp  = _gw / max(1,_gh);

    var _rw, _rh, _rx, _ry;
    if (_guiAsp > _aspect) {
        _rh = _gh;
        _rw = floor(_rh * _aspect);
        _rx = (_gw - _rw) div 2;
        _ry = 0;
    } else {
        _rw = _gw;
        _rh = floor(_rw / _aspect);
        _rx = 0;
        _ry = (_gh - _rh) div 2;
    }
    return [_rx, _ry, _rw, _rh];
}

// ===== Battlers drawing (top-level helper) =====
function __battle_draw_battlers(_pid, _B) {
    var foe_x_log = 165, foe_y_log = 40;
    var mon_x_log = 64,  mon_y_log = 112;
    var trainer_x_log = 32, trainer_y_log = 108;
    var scale_foe = 1.0, scale_us = 1.1;

    var fx = __bxu(_pid, foe_x_log);
    var fy = __byu(_pid, foe_y_log);
    var mx = __bxu(_pid, mon_x_log);
    var my = __byu(_pid, mon_y_log);
    var tx = __bxu(_pid, trainer_x_log);
    var ty = __byu(_pid, trainer_y_log);

    // Enemy
    var E = _B.actor[1];
    if (is_struct(E) && variable_struct_exists(E, "mon")) {
        if (string(_B.phase) != "transition_in") {
            var mE = E.mon;
            if (!is_undefined(pkicons_get_art96_by_mon) && !is_undefined(pkicons_get_art96_subimg_by_mon)) {
                var sprE = pkicons_get_art96_by_mon(mE);
                var subE = pkicons_get_art96_subimg_by_mon(mE, false); // front
                if (sprite_exists(sprE)) {
                    var w = sprite_get_width(sprE);
                    var h = sprite_get_height(sprE);
                    var _ui = __battle_ensure_slot(_pid)._ui;
                    var ui_s = (is_struct(_ui) && variable_struct_exists(_ui,"s")) ? _ui.s : 1;
                    var drawScaleE = scale_foe * ui_s;
                    var draw_x = fx - (w*drawScaleE)/2;
                    var draw_y = fy - (h*drawScaleE)/2;
                    if (string(_B.phase) == "intro_enemy"){
                        var p = (variable_struct_exists(_B,"phase_progress") ? _B.phase_progress : 0);
                        var start_log = 240 + 40; // 280
                        var start_px = __bxu(_pid, start_log);
                        var target_px = fx - (w*drawScaleE)/2;
                        var t = 1 - (1 - p) * (1 - p);
                        draw_x = floor(lerp(start_px, target_px, t));
                    }
                        // apply subtle breathing X-scale when idle (command) to make the pokemon 'breathe'
                        var _breath_amp = 0.03; // 3% width change
                        var _breath_period = 2000; // ms per cycle (slower)
                        var _bs_e = 1;
                        if (string(_B.phase) == "command"){
                            var _tms = current_time;
                            _bs_e = 1 + sin((_tms * 2 * pi) / _breath_period) * _breath_amp;
                        }
                        // draw a subtle shadow/ground ellipse under the enemy using the X-scale for width
                        draw_set_color(make_color_rgb(20,20,20));
                        draw_set_alpha(0.45);
                        var shadow_w_e = floor((w * drawScaleE * _bs_e) * 0.6);
                        var shadow_h_e = max(2, floor((w * drawScaleE) * 0.12));
                        var shadow_cx_e = floor(draw_x + (w * drawScaleE * _bs_e) * 0.5);
                        var shadow_cy_e = floor(draw_y + (h * drawScaleE) * 0.5 + shadow_h_e * 0.8 + floor(15 * ui_s));
                        draw_ellipse(shadow_cx_e - shadow_w_e div 2, shadow_cy_e - shadow_h_e div 2, shadow_cx_e + shadow_w_e div 2, shadow_cy_e + shadow_h_e div 2, false);
                        draw_set_alpha(1);
                        draw_sprite_ext(sprE, subE, draw_x, draw_y, drawScaleE * _bs_e, drawScaleE, 0, c_white, 1);
                }
            }
        }
    }

    // Player
    var P = _B.actor[0];
    if (is_struct(P) && variable_struct_exists(P, "mon")) {
        var mP = P.mon;
        if (!is_undefined(pkicons_get_art96_by_mon) && !is_undefined(pkicons_get_art96_subimg_by_mon)) {
            var sprP = pkicons_get_art96_by_mon(mP);
            var subP = pkicons_get_art96_subimg_by_mon(mP, true); // back
            if (sprite_exists(sprP)) {
                var w = sprite_get_width(sprP);
                var h = sprite_get_height(sprP);
                var _ui = __battle_ensure_slot(_pid)._ui;
                var ui_s = (is_struct(_ui) && variable_struct_exists(_ui,"s")) ? _ui.s : 1;
                var drawScaleP = scale_us * ui_s;
                var draw_x = mx - (w*drawScaleP)/2;
                var draw_y = my - (h*drawScaleP)/2;

                if (string(_B.phase) == "intro_call"){
                    var p2 = (variable_struct_exists(_B,"phase_progress") ? _B.phase_progress : 0);
                    var slide_frac = 0.35;
                    var start_log = -40;
                    var start_px = __bxu(_pid, start_log);
                    var target_px = tx;
                    var trainer_x_px = (p2 < slide_frac) ? floor(lerp(start_px, target_px, 1 - (1 - (p2 / slide_frac)) * (1 - (p2 / slide_frac)))) : tx;

                    // Only play the caller animation during the intro call or during a switch_in phase
                    var _phase = string(_B.phase);
                    var _anim_phase_allowed = (_phase == "intro_call" || _phase == "switch_in");
                    if (_anim_phase_allowed && variable_struct_exists(_B, "caller_battleAnim") && !is_undefined(_B.caller_battleAnim) && sprite_exists(_B.caller_battleAnim)){
                        var bs = _B.caller_battleAnim;
                        var frames = max(1, sprite_get_number(bs));
                        var now_ms = current_time;
                        var call_start = (variable_struct_exists(_B, "phase_start_ms") ? _B.phase_start_ms : now_ms);
                        var call_dur = max(1, real(_B.phase_durs.call));
                        var hold_ms = 0;
                        if (variable_struct_exists(_B, "phase_holds") && variable_struct_exists(_B.phase_holds, "call")) hold_ms = max(0, real(_B.phase_holds.call));
                        var slide_ms = floor(call_dur * slide_frac);
                        var anim_ms = call_dur - slide_ms;
                        var elapsed_ms = now_ms - call_start;

                        var draw_frame = 0;
                        if (elapsed_ms < slide_ms){ draw_frame = 0; }
                        else if (elapsed_ms < slide_ms + anim_ms){
                            var anim_elapsed = elapsed_ms - slide_ms;
                            if (frames <= 1){ draw_frame = 0; }
                            else {
                                var prog = clamp(anim_elapsed / max(1, anim_ms), 0, 0.999999);
                                draw_frame = floor(prog * frames);
                                if (draw_frame >= frames) draw_frame = frames - 1;
                            }
                        } else if (elapsed_ms < slide_ms + anim_ms + hold_ms){ draw_frame = max(0, frames - 1); }
                        else { draw_frame = max(0, frames - 1); }

                            var bx = trainer_x_px - (sprite_get_width(bs)*ui_s)/2;
                            var by = ty - (sprite_get_height(bs)*ui_s)/2;
                            draw_sprite_ext(bs, draw_frame, bx, by, ui_s, ui_s, 0, c_white, 1);
                            // If this is the normal intro call, stop here (trainer covers the scene).
                            if (string(_B.phase) == "intro_call") return;
                    }

                    if (_anim_phase_allowed && variable_global_exists("battleAnim") && sprite_exists(battleAnim)){
                        var bs2 = battleAnim;
                        var frames2 = max(1, sprite_get_number(bs2));
                        var now_ms2 = current_time;
                        var call_start2 = (variable_struct_exists(_B, "phase_start_ms") ? _B.phase_start_ms : now_ms2);
                        var call_dur2 = max(1, real(_B.phase_durs.call));
                        var hold_ms2 = 0;
                        if (variable_struct_exists(_B, "phase_holds") && variable_struct_exists(_B.phase_holds, "call")) hold_ms2 = max(0, real(_B.phase_holds.call));
                        var slide_ms2 = floor(call_dur2 * slide_frac);
                        var anim_ms2 = call_dur2 - slide_ms2;
                        var elapsed_ms2 = now_ms2 - call_start2;

                        var draw_frame2 = 0;
                        if (elapsed_ms2 < slide_ms2){ draw_frame2 = 0; }
                        else if (elapsed_ms2 < slide_ms2 + anim_ms2){
                            var anim_elapsed2 = elapsed_ms2 - slide_ms2;
                            if (frames2 <= 1){ draw_frame2 = 0; }
                            else {
                                var prog2 = clamp(anim_elapsed2 / max(1, anim_ms2), 0, 0.999999);
                                draw_frame2 = floor(prog2 * frames2);
                                if (draw_frame2 >= frames2) draw_frame2 = frames2 - 1;
                            }
                        } else if (elapsed_ms2 < slide_ms2 + anim_ms2 + hold_ms2){ draw_frame2 = max(0, frames2 - 1); }
                        else { draw_frame2 = max(0, frames2 - 1); }

                        var bx2 = trainer_x_px - (sprite_get_width(bs2)*ui_s)/2;
                        var by2 = ty - (sprite_get_height(bs2)*ui_s)/2;
                        draw_sprite_ext(bs2, draw_frame2, bx2, by2, ui_s, ui_s, 0, c_white, 1);
                        // If this is the normal intro call, stop here (trainer covers the scene).
                        if (string(_B.phase) == "intro_call") return;
                    }
                }

                if (string(_B.phase) == "intro_player"){
                    var p3 = (variable_struct_exists(_B,"phase_progress") ? _B.phase_progress : 0);
                    var t3 = 1 - (1 - p3) * (1 - p3);
                    var minScale = 0.4;
                    var targetScale = drawScaleP;
                    var curScale = lerp(minScale * ui_s, targetScale, t3);
                    var draw_x2 = mx - (w*curScale)/2;
                    var draw_y2 = my - (h*curScale)/2;
                    draw_set_color(make_color_rgb(20,20,20));
                    draw_set_alpha(0.45);
                    var shadow_w_p = floor((w * curScale) * 0.6);
                    var shadow_h_p = max(2, floor((w * curScale) * 0.12));
                    var shadow_cx_p = floor(draw_x2 + (w * curScale) * 0.5);
                    var shadow_cy_p = floor(draw_y2 + (h * curScale) * 0.5 + shadow_h_p * 0.8 + floor(15 * ui_s));
                    draw_ellipse(shadow_cx_p - shadow_w_p div 2, shadow_cy_p - shadow_h_p div 2, shadow_cx_p + shadow_w_p div 2, shadow_cy_p + shadow_h_p div 2, false);
                    draw_set_alpha(1);
                    draw_sprite_ext(sprP, subP, draw_x2, draw_y2, curScale, curScale, 0, c_white, 1);
                } else if (string(_B.phase) == "command"){
                    // apply subtle breathing X-scale when idle (command)
                    var _breath_amp_p = 0.03;
                    var _breath_period_p = 2000;
                    var _bs_p = 1;
                    if (string(_B.phase) == "command"){
                        var _tms_p = current_time;
                        // offset player's breathing by half the period so they alternate with the enemy
                        var _offset = floor(_breath_period_p / 2);
                        _bs_p = 1 + sin(((_tms_p + _offset) * 2 * pi) / _breath_period_p) * _breath_amp_p;
                    }
                    draw_set_color(make_color_rgb(20,20,20));
                    draw_set_alpha(0.45);
                    var shadow_w_p2 = floor((w * drawScaleP * _bs_p) * 0.6);
                    var shadow_h_p2 = max(2, floor((w * drawScaleP) * 0.12));
                    var shadow_cx_p2 = floor(draw_x + (w * drawScaleP * _bs_p) * 0.5);
                    var shadow_cy_p2 = floor(draw_y + (h * drawScaleP) * 0.5 + shadow_h_p2 * 0.8 + floor(15 * ui_s));
                    draw_ellipse(shadow_cx_p2 - shadow_w_p2 div 2, shadow_cy_p2 - shadow_h_p2 div 2, shadow_cx_p2 + shadow_w_p2 div 2, shadow_cy_p2 + shadow_h_p2 div 2, false);
                    draw_set_alpha(1);
                    draw_sprite_ext(sprP, subP, draw_x, draw_y, drawScaleP * _bs_p, drawScaleP, 0, c_white, 1);
                }
                // ---- switch_in visuals: outgoing shrink -> swap -> incoming grow
                if (string(_B.phase) == "switch_in"){
                    var prog = (variable_struct_exists(_B, "phase_progress") ? _B.phase_progress : 0);
                    // define timings: first half = outgoing, second half = incoming
                    var out_prog = min(1, prog * 2);
                    var in_prog = max(0, (prog - 0.5) * 2);

                    var outScale = lerp(drawScaleP, drawScaleP * 0.4, out_prog);
                    var inScale = lerp(drawScaleP * 0.4, drawScaleP, in_prog);

                    // draw outgoing scaled down during first half
                    if (prog < 0.5){
                        var draw_x_out = mx - (w * outScale) / 2;
                        var draw_y_out = my - (h * outScale) / 2;
                        draw_set_color(make_color_rgb(20,20,20)); draw_set_alpha(0.45);
                        var sw = floor((w * outScale) * 0.6);
                        var sh = max(2, floor((w * outScale) * 0.12));
                        var scx = floor(draw_x_out + (w * outScale) * 0.5);
                        var scy = floor(draw_y_out + (h * outScale) * 0.5 + sh * 0.8 + floor(15 * ui_s));
                        draw_ellipse(scx - sw div 2, scy - sh div 2, scx + sw div 2, scy + sh div 2, false);
                        draw_set_alpha(1);
                        draw_sprite_ext(sprP, subP, draw_x_out, draw_y_out, outScale, outScale, 0, c_white, 1);
                        // mid-swap point: when out_prog reaches 1, apply the new mon
                        if (out_prog >= 1 && variable_struct_exists(_B, "_switch_target_idx")){
                            var idx = _B._switch_target_idx;
                            var opts = (variable_struct_exists(_B, "_switch_opts") ? _B._switch_opts : {});
                            // apply by default
                            var auto_apply = !(variable_struct_exists(opts, "auto_apply") && opts.auto_apply == false);
                            if (auto_apply && !is_undefined(party_ensure)){
                                var P = party_ensure(_pid);
                                if (is_array(P.mons) && idx >= 0 && idx < array_length(P.mons)){
                                    _B.actor[0] = __battle_actor_from_party_mon(P.mons[idx]);
                                }
                            }
                            // clear the stored target so we don't reapply
                            _B._switch_target_idx = undefined;
                        }
                    } else {
                        // incoming: draw the current actor[0] scaled up
                        var curA = _B.actor[0];
                        var draw_x_in = mx - (w * inScale) / 2;
                        var draw_y_in = my - (h * inScale) / 2;
                        draw_set_color(make_color_rgb(20,20,20)); draw_set_alpha(0.45);
                        var sw2 = floor((w * inScale) * 0.6);
                        var sh2 = max(2, floor((w * inScale) * 0.12));
                        var scx2 = floor(draw_x_in + (w * inScale) * 0.5);
                        var scy2 = floor(draw_y_in + (h * inScale) * 0.5 + sh2 * 0.8 + floor(15 * ui_s));
                        draw_ellipse(scx2 - sw2 div 2, scy2 - sh2 div 2, scx2 + sw2 div 2, scy2 + sh2 div 2, false);
                        draw_set_alpha(1);
                        draw_sprite_ext(sprP, subP, draw_x_in, draw_y_in, inScale, inScale, 0, c_white, 1);
                    }
                }
            }
        }
    }
}
