// [Battle] PokemonBattleSystem — Build v0.1.30 (PID, GUI, Letterbox)
// Updated 2025-10-06
// - PID-aware (works for local/online later): state lives in global.sys_battles[pid]
// - Draws entirely in Draw GUI (no camera dependency)
// - 240×160 logical canvas with letterbox fit
// - Command box fixed at y=136 (24px high) to fit exactly
// - Minimal move seeding; plugs into your Party system and species helpers
// -----------------------------------------------------------------------------
// CALLS you’ll use in objects:
//   battle_open(pid, wild_level);      // e.g., battle_open(0, irandom_range(5,18));
//   battle_update(pid);                // Step Event
//   battle_draw_gui(pid);              // Draw GUI Event
//   battle_close(pid);                 // when done
// -----------------------------------------------------------------------------

// ===== Slot helpers (per-player battle state) =====
function __battle_ensure_slot(_pid){
    if (!variable_global_exists("sys_battles") || !is_array(global.sys_battles)) global.sys_battles = [];
    if (array_length(global.sys_battles) <= _pid) array_resize(global.sys_battles, _pid + 1);
    var _B = global.sys_battles[_pid];
    if (!is_struct(_B)) { _B = { sys_open:false }; global.sys_battles[_pid] = _B; }
    return _B;
}
function battle_is_open(_pid){
    var _B = __battle_ensure_slot(_pid);
    return (_B.sys_open == true);
}

// ===== Open / Close =====
function battle_open(_a0, _a1){
    var _pid = 0, _wildLevel = 5;
    if (argument_count >= 2){ _pid = max(0, real(_a0)); _wildLevel = max(1, real(_a1)); }
    else if (argument_count == 1){ _pid = 0; _wildLevel = max(1, real(_a0)); }

    var _B = __battle_ensure_slot(_pid);
    if (_B.sys_open) return;

    _B.sys_open = true;
    _B.phase    = "transition_in";
    _B.turn     = 0;
    _B.result   = "ongoing";
    _B.sys_rng  = random_get_seed();

    _B.sys_ui   = { menu:"root", selX:0, selY:0, msg_list:ds_list_create() };
    _B.sys_anim = { active:[
        {anim_id:"idle",timer:0,duration:999999,offX:0,offY:0,scale:1},
        {anim_id:"idle",timer:0,duration:999999,offX:0,offY:0,scale:1}
    ]};

    _B.theme = {
        col_bg:       make_color_rgb(184,224,200),
        col_outline:  make_color_rgb(72,88,80),
        col_panel:    make_color_rgb(208,232,224),
        col_hp_green: make_color_rgb(120,216,88),
        col_hp_yell:  make_color_rgb(248,208,56),
        col_hp_red:   make_color_rgb(232,72,56),
        col_text:     c_black
    };

    // Player actor from that player's party
    var _P = party_ensure(_pid);
    var _mons = _P.mons;
    var _first = 0;
    for (var _i=0; _i<array_length(_mons); ++_i){
        var _m = _mons[_i];
        if (!is_undefined(_m) && is_struct(_m) && variable_struct_exists(_m,"hp") && _m.hp > 0){ _first = _i; break; }
    }
    var _pm = _mons[_first];

    _B.actor = [];
    _B.actor[0] = __battle_actor_from_party_mon(_pm);

    // Wild actor (1..901 only)
    var _sp = irandom_range(1, 901);
    _B.actor[1] = __battle_actor_from_species_level(_sp, _wildLevel);

    __battle_ensure_moves_from_levelup(_B.actor[0]);
    __battle_ensure_moves_from_levelup(_B.actor[1]);

    global.sys_battles[_pid] = _B;
}
function battle_close(_pid){
    var _B = __battle_ensure_slot(_pid);
    _B.sys_open = false;
}

// ===== Update / Draw =====
function battle_update(_pid){
    if (!battle_is_open(_pid)) return;
    var _B = __battle_ensure_slot(_pid);

    if (_B.phase == "transition_in"){ _B.phase = "command"; return; }
    __battle_process_input(_pid);
}

function battle_draw_gui(_pid){
    if (!battle_is_open(_pid)) return;
    var _B = __battle_ensure_slot(_pid);
    var _rect = __battle_view_rect_for_pid(_pid); // [rx,ry,rw,rh] letterboxed inside GUI

    // begin UI scale context
    __bui_begin(_pid, _rect[0], _rect[1], _rect[2], _rect[3]);

    // background
    draw_set_color(_B.theme.col_bg);
    draw_rectangle(__bxu(_pid,0), __byu(_pid,0), __bxu(_pid,240), __byu(_pid,160), false);

    // HUD boxes (fit within 240×160)
    __battle_enemy_box_rect(_pid, 16,16,112,40, _B.actor[1]);
    __battle_player_box_rect(_pid,112,104,128,48, _B.actor[0]);
    __battle_cmd_box_rect(_pid,   8,136,224,24,   _B.sys_ui.selX, _B.sys_ui.selY); // 136+24=160

    __bui_end(_pid);
}

// ===== Input (PID-aware; falls back to keyboard) =====
function __battle_pressed(_pid, _name){
    if (!is_undefined(controls_pressed)) return controls_pressed(_pid, _name);
    if (_name=="Left")  return keyboard_check_pressed(vk_left);
    if (_name=="Right") return keyboard_check_pressed(vk_right);
    if (_name=="Up")    return keyboard_check_pressed(vk_up);
    if (_name=="Down")  return keyboard_check_pressed(vk_down);
    if (_name=="A")     return keyboard_check_pressed(vk_enter);
    if (_name=="B")     return keyboard_check_pressed(vk_escape);
    return false;
}
function __battle_process_input(_pid){
    // Placeholder navigation; hook to your menu later
    var _l = __battle_pressed(_pid,"Left");
    var _r = __battle_pressed(_pid,"Right");
    var _u = __battle_pressed(_pid,"Up");
    var _d = __battle_pressed(_pid,"Down");
    var _a = __battle_pressed(_pid,"A");
    var _b = __battle_pressed(_pid,"B");

    var _B = __battle_ensure_slot(_pid);
    if (_l) _B.sys_ui.selX = max(0, _B.sys_ui.selX - 1);
    if (_r) _B.sys_ui.selX = min(1, _B.sys_ui.selX + 1);
    if (_u) _B.sys_ui.selY = max(0, _B.sys_ui.selY - 1);
    if (_d) _B.sys_ui.selY = min(1, _B.sys_ui.selY + 1);
    if (_b) { /* back/cancel later */ }
    if (_a) { /* confirm later */ }
}

// ===== Actor creation =====
function __battle_actor_from_party_mon(_M){
    var _sid = -1;
    if (variable_struct_exists(_M,"id") && is_real(_M.id)) _sid = _M.id;
    else if (variable_struct_exists(_M,"species_id") && is_real(_M.species_id)) _sid = _M.species_id;

    var _nm = "???";
    if (variable_struct_exists(_M,"name") && is_string(_M.name) && string_length(_M.name) > 0) _nm = string(_M.name);
    else if (_sid > 0) _nm = scr_poke_name_by_id(_sid);

    var _hpMax = 20;
    if (variable_struct_exists(_M,"hp_max"))      _hpMax = _M.hp_max;
    else if (variable_struct_exists(_M,"maxhp"))  _hpMax = _M.maxhp;

    var _hpNow = variable_struct_exists(_M,"hp") ? _M.hp : _hpMax;

    var _lvl   = 5;
    if (variable_struct_exists(_M,"level")) _lvl = _M.level;
    else if (variable_struct_exists(_M,"lvl")) _lvl = _M.lvl;

    var _actor = {
        species : _sid,
        level   : _lvl,
        name    : _nm,
        hp_now  : _hpNow,
        hp_max  : _hpMax,
        moves   : [-1,-1,-1,-1],
        pps     : [0,0,0,0]
    };
    return _actor;
}
function __battle_actor_from_species_level(_sp,_lvl){
    var _nm = scr_poke_name_by_id(_sp);
    var _actor = {
        species:_sp,
        level:_lvl,
        name:_nm,
        hp_now:30,
        hp_max:30,
        moves:[-1,-1,-1,-1],
        pps:[0,0,0,0]
    };
    return _actor;
}

// ===== Move population =====
function __battle_ensure_moves_from_levelup(_A){
    // reset
    for (var i=0; i<4; ++i){ _A.moves[i] = -1; _A.pps[i] = 0; }

    // simplest seed from your helpers if available
    if (!is_undefined(scr_poke_moveset_by_id)){
        var _pool = scr_poke_moveset_by_id(_A.species);
        if (is_array(_pool) && array_length(_pool) > 0){
            // pick up to 4 last (most recent) moves <= level if you later have [move, lvl] tuples
            _A.moves[0] = _pool[0];
            _A.pps[0]   = 10;
        }
    }
}

// ===== Rect pipeline (PID-aware, GUI-only) =====
function __bui_begin(_pid,_rx,_ry,_rw,_rh){
    // Create a stacked UI context so nested UI (chat/etc.) cannot clobber
    if (!variable_global_exists("_bui_stack") || !is_array(global._bui_stack)) global._bui_stack = [];
    var _prev = variable_global_exists("_bui_current") ? global._bui_current : undefined;
    array_push(global._bui_stack, _prev);

    var _ui = { rx:_rx, ry:_ry, rw:_rw, rh:_rh, base_w:240, base_h:160 };
    _ui.sx = (_rw <= 0) ? 1 : (_rw / 240);
    _ui.sy = (_rh <= 0) ? 1 : (_rh / 160);
    global._bui_current = _ui;

    // Also keep compatibility with slot-local UI
    var _B = __battle_ensure_slot(_pid);
    _B._ui = _ui;
}
function __bui_end(_pid){
    // Pop previous UI context
    var _prev = undefined;
    if (variable_global_exists("_bui_stack") && is_array(global._bui_stack) && array_length(global._bui_stack) > 0) {
        _prev = array_pop(global._bui_stack);
    }
    global._bui_current = _prev;

    var _B = __battle_ensure_slot(_pid);
    _B._ui = _prev;
}
function __bxu(_pid,_xv){
    var _u = (variable_global_exists("_bui_current") && is_struct(global._bui_current)) ? global._bui_current : __battle_ensure_slot(_pid)._ui;
    if (!is_struct(_u)) return floor(_xv);
    return floor(_u.rx + _xv * _u.sx);
}
function __byu(_pid,_yv){
    var _u = (variable_global_exists("_bui_current") && is_struct(global._bui_current)) ? global._bui_current : __battle_ensure_slot(_pid)._ui;
    if (!is_struct(_u)) return floor(_yv);
    return floor(_u.ry + _yv * _u.sy);
}
function __bwu(_pid,_wv){
    var _u = (variable_global_exists("_bui_current") && is_struct(global._bui_current)) ? global._bui_current : __battle_ensure_slot(_pid)._ui;
    if (!is_struct(_u)) return floor(_wv);
    return floor(_wv * _u.sx);
}
function __bhu(_pid,_hv){
    var _u = (variable_global_exists("_bui_current") && is_struct(global._bui_current)) ? global._bui_current : __battle_ensure_slot(_pid)._ui;
    if (!is_struct(_u)) return floor(_hv);
    return floor(_hv * _u.sy);
}


// ===== Panels & HUD (PID-aware) =====
function __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn){
    var _t  = __battle_ensure_slot(_pid).theme;
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn);
    var _bw = __bwu(_pid,_rwIn), _bh = __bhu(_pid,_rhIn);
    draw_set_color(_t.col_outline); draw_rectangle(_bx,_by,_bx+_bw,_by+_bh,false);
    draw_set_color(_t.col_panel);   draw_rectangle(_bx+1,_by+1,_bx+_bw-1,_by+_bh-1,false);
}
function __battle_enemy_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_A){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn);
    draw_set_color(_t.col_text);
    draw_text(_bx+__bwu(_pid,8), _by+__bhu(_pid,6), string(_A.name));
    draw_text(_bx+_bw-__bwu(_pid,32), _by+__bhu(_pid,6), "Lv"+string(_A.level));
    var _pct = max(0, min(1, _A.hp_now / max(1,_A.hp_max)));
    var _barW = _bw-__bwu(_pid,32), _barX=_bx+__bwu(_pid,8), _barY=_by+__bhu(_pid,20), _bh=__bhu(_pid,6);
    draw_set_color(c_black); draw_rectangle(_barX-1,_barY-1,_barX+_barW+1,_barY+_bh+1,false);
    var _hpcol = _t.col_hp_green; if (_pct<0.5) _hpcol=_t.col_hp_yell; if (_pct<0.2) _hpcol=_t.col_hp_red;
    draw_set_color(_hpcol); draw_rectangle(_barX,_barY,_barX+_barW*_pct,_barY+_bh,false);
}
function __battle_player_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_A){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn);
    draw_set_color(_t.col_text);
    draw_text(_bx+__bwu(_pid,8), _by+__bhu(_pid,6), string(_A.name));
    draw_text(_bx+_bw-__bwu(_pid,32), _by+__bhu(_pid,6), "Lv"+string(_A.level));
    var _pct = max(0, min(1, _A.hp_now / max(1,_A.hp_max)));
    var _barW = _bw-__bwu(_pid,32), _barX=_bx+__bwu(_pid,8), _barY=_by+__bhu(_pid,20), _bh=__bhu(_pid,6);
    draw_set_color(c_black); draw_rectangle(_barX-1,_barY-1,_barX+_barW+1,_barY+_bh+1,false);
    var _hpcol = _t.col_hp_green; if (_pct<0.5) _hpcol=_t.col_hp_yell; if (_pct<0.2) _hpcol=_t.col_hp_red;
    draw_set_color(_hpcol); draw_rectangle(_barX,_barY,_barX+_barW*_pct,_barY+_bh,false);
    draw_text(_bx+_bw-__bwu(_pid,64), _by+__bhu(_pid,18), string(_A.hp_now)+"/"+string(_A.hp_max));
}
function __battle_cmd_box_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn,_selX,_selY){
    var _t  = __battle_ensure_slot(_pid).theme;
    __battle_panel_rect(_pid,_rxIn,_ryIn,_rwIn,_rhIn);
    var _bx = __bxu(_pid,_rxIn), _by = __byu(_pid,_ryIn), _bw = __bwu(_pid,_rwIn), _bh = __bhu(_pid,_rhIn);
    var _labels = ["FIGHT","BAG","POK\u00E9MON","RUN"];
    for (var _i=0; _i<4; ++_i){
        var _tx = _bx + __bwu(_pid,12) + ((_i % 2) * (_bw * 0.5));
        var _ty = _by + __bhu(_pid,6)  + (floor(_i / 2) * (_bh * 0.5));
        var _hilite = (_selX == (_i % 2)) && (_selY == floor(_i / 2));
        draw_set_color(_hilite ? c_yellow : _t.col_text);
        draw_text(_tx,_ty,_labels[_i]);
    }
}

// ===== GUI Letterbox rect (per PID, GUI-only; cameras ignored) =====
function __battle_view_rect_for_pid(_pid){
    var _gw = display_get_gui_width();
    var _gh = display_get_gui_height();

    var _logic_w = 240;
    var _logic_h = 160;
    var _aspect  = _logic_w / _logic_h; // 1.5
    var _guiAsp  = _gw / max(1,_gh);

    var _rw, _rh, _rx, _ry;
    if (_guiAsp > _aspect) {
        _rh = _gh;
        _rw = floor(_rh * _aspect);
        _rx = (_gw - _rw) div 2;
        _ry = 0;
    } else {
        _rw = _gw;
        _rh = floor(_rw / _aspect);
        _rx = 0;
        _ry = (_gh - _rh) div 2;
    }
    return [_rx, _ry, _rw, _rh];
}
