// [Pokémon Data]: PokemonDataLoaders_Debug — Build v1.0.1 — Updated 2025-10-04
// Purpose: Profile per-loader CSV ingestion times without modifying existing systems.
// Fix v1.0.1: Avoid dynamic string indexing on structs (GML doesn't allow). Now we store
//             per-target results in an array of entry-structs: metrics.sys_items[].
// Behavior: Attempts to resolve common loader scripts via asset_get_index + script_execute.
//           Logs individual durations and totals to the output (show_debug_message) and
//           writes a CSV log to Documents/Pokemon Engine/logs/.
// Safety:   Adds NEW functions only. No renames, no deletions.
// Naming:   Local vars `_camelCase`; system fields `sys_*` / `engine_*`; avoid reserved names.
//
// How to use (example from oGame.Create):
//   var _metrics = data_load_profile_run();
//   // Inspect _metrics.sys_items: array of { label, ok, ms }
//
// Returned struct fields:
//   metrics.sys_total_ms   (real)
//   metrics.sys_items      (array of structs: { label, ok, ms })
//   metrics.sys_entries    (count of attempted targets)
//   metrics.sys_log_path   (CSV path written)
//
// ------------------------------------------------------------
// INTERNAL CONSTANTS
#macro DLP_MAGIC          0xD1CEBEEF
#macro DLP_VERSION        101  // 1.0.1
#macro DLP_LOG_HEADER     "timestamp,label,ok,ms"
#macro DLP_DIR_LOGS_WIN   "\\Documents\\Pokemon Engine\\logs\\"
#macro DLP_DIR_LOGS_UNIX  "/Documents/Pokemon Engine/logs/"
#macro DLP_FILE_PREFIX    "load_profile_"

// ------------------------------------------------------------
// Public entry point
/// data_load_profile_run()
/// @return struct metrics
function data_load_profile_run() {
    var _metrics = {
        sys_magic    : DLP_MAGIC,
        sys_version  : DLP_VERSION,
        sys_entries  : 0,
        sys_total_ms : 0.0,
        sys_log_path : "",
        sys_items    : []
    };

    var _logDir = __dlp_logs_dir();
    __dlp_ensure_dir(_logDir);
    var _logPath = __dlp_new_log_path(_logDir);
    _metrics.sys_log_path = _logPath;

    __dlp_write_line(_logPath, DLP_LOG_HEADER);

    // Candidate loader scripts (missing ones are skipped safely)
    var _targets = [
        "data_load_pokemon_csv",
        "data_load_stats_csv",
        "data_load_moves_csv",
        "data_load_move_text_csv",
        "data_load_abilities_csv",
        "data_load_ability_text_csv",
        "data_load_type_eff_csv",
        "data_load_species_evo_csv",
        // Orchestrator last:
        "data_load_all_structs"
    ];

    var _i, _n = array_length(_targets);
    var _grandStart = __dlp_now();

    for (_i = 0; _i < _n; _i++) {
        var _label = _targets[_i];
        var _asset = asset_get_index(_label);
        var _ok = false;
        var _ms = 0.0;

        if (_asset != -1) {
            var _t0 = __dlp_now();
            _ok = script_execute(_asset);
            var _t1 = __dlp_now();
            _ms = __dlp_ms(_t0, _t1);
        } else {
            _ok = false;
            _ms = 0.0;
        }

        var _entry = {
            label : _label,
            ok    : _ok,
            ms    : _ms
        };

        _metrics.sys_items = __dlp_array_push(_metrics.sys_items, _entry);
        _metrics.sys_entries += 1;

        var _stamp = __dlp_timestamp();
        var _okStr = _ok ? "1" : "0";
        var _line = _stamp + "," + _label + "," + _okStr + "," + string(_ms);
        __dlp_write_line(_logPath, _line);

        show_debug_message("[DLP] " + _label + " → ok=" + string(_ok) + " ms=" + string(_ms));
    }

    var _grandEnd = __dlp_now();
    _metrics.sys_total_ms = __dlp_ms(_grandStart, _grandEnd);
    show_debug_message("[DLP] TOTAL ms=" + string(_metrics.sys_total_ms));
    __dlp_write_line(_logPath, __dlp_timestamp() + ",TOTAL,1," + string(_metrics.sys_total_ms));

    return _metrics;
}

// ------------------------------------------------------------
// Helpers
function __dlp_array_push(_arr, _val) {
    var _len = array_length(_arr);
    _arr[_len] = _val;
    return _arr;
}

function __dlp_now() {
    return get_timer(); // microseconds
}

function __dlp_ms(_t0, _t1) {
    var _us = _t1 - _t0;
    return _us / 1000.0;
}

function __dlp_timestamp() {
    var _yy = string_format(date_get_year(date_current_datetime()), 4, 0);
    var _mm = string_format(date_get_month(date_current_datetime()), 2, 0);
    var _dd = string_format(date_get_day(date_current_datetime()), 2, 0);
    var _hh = string_format(date_get_hour(date_current_datetime()), 2, 0);
    var _mi = string_format(date_get_minute(date_current_datetime()), 2, 0);
    var _ss = string_format(date_get_second(date_current_datetime()), 2, 0);
    return _yy + _mm + _dd + "_" + _hh + _mi + _ss;
}

// Return the absolute logs directory in Documents
function __dlp_logs_dir() {
    var _userProf = environment_get_variable("USERPROFILE");
    var _home = environment_get_variable("HOME");
    if (!is_undefined(_userProf) && string_length(_userProf) > 0) {
        return _userProf + DLP_DIR_LOGS_WIN;
    } else if (!is_undefined(_home) && string_length(_home) > 0) {
        return _home + DLP_DIR_LOGS_UNIX;
    } else {
        return working_directory + "Pokemon_Engine/logs/";
    }
}

function __dlp_ensure_dir(_absDir) {
    if (!directory_exists(_absDir)) {
        directory_create(_absDir);
    }
}

function __dlp_new_log_path(_absDir) {
    var _ts = __dlp_timestamp();
    return _absDir + DLP_FILE_PREFIX + _ts + ".csv";
}

function __dlp_write_line(_absPath, _text) {
    var _fh;
    if (file_exists(_absPath)) {
        _fh = file_text_open_append(_absPath);
        if (_fh >= 0) {
            file_text_write_string(_fh, _text);
            file_text_writeln(_fh);
            file_text_close(_fh);
        }
    } else {
        _fh = file_text_open_write(_absPath);
        if (_fh >= 0) {
            file_text_write_string(_fh, _text);
            file_text_writeln(_fh);
            file_text_close(_fh);
        }
    }
}
